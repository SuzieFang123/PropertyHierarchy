

import static java.lang.Math.abs;



/*
 * Class for house, extending from property
 */
public class House extends Property {
    private int bathroomNumbers;
    private double depthOfTheLot;
    private double withOfTheLot;
    private double floorSpace;
    private int bedroomNumbers;

    /*
     * Setters and getters for the attributes
     */
    public int getBedroomNumbers() {
        return bedroomNumbers;
    }

    public void setBedroomNumbers(int bedroomNumbers) throws IllegalInput {
        if(bedroomNumbers <= 0){
            throw new IllegalInput("# of Bedrooms can't be 0!");
        }
        this.bedroomNumbers = bedroomNumbers;
    }

    public int getBathroomNumbers() {
        return bathroomNumbers;
    }
    /*
     * checking for exceptions
     */

    public void setBathroomNumbers(int bathroomNumbers) throws IllegalInput {
        if(bathroomNumbers <= 0){
            throw new IllegalInput("# of Bathrooms can't be 0!");

        }
        this.bathroomNumbers = bathroomNumbers;
    }

    public double getDepthOfTheLot() {
        return depthOfTheLot;
    }

    public double getWithOfTheLot() {
        return withOfTheLot;
    }

    public double getFloorSpace() {
        return floorSpace;
    }

    public void setFloorSpace(double floorSpace) {
        this.floorSpace = floorSpace;
    }

    public void setWithOfTheLot(double withOfTheLot) {
        this.withOfTheLot = withOfTheLot;
    }

    public void setDepthOfTheLot(double depthOfTheLot) {
        this.depthOfTheLot = depthOfTheLot;
    }
    /*
     * Tax calculator to calculate the tax
     */
    public void TaxCalculator() {
        double Tax_House = 1000 + 50 * bathroomNumbers + 10 * floorSpace;
        System.out.println(Tax_House);
    }

    enum HouseTypes {
        TOWNHOUSE, DETACHED, DUPLEX, WATERFRONT_HOME
    }

    private House.HouseTypes houseTypes;


    public House(double listingPrice, int bathroomNumbers, double depthOfTheLot, double withOfTheLot, double floorSpace, int bedroomNumbers, HouseTypes houseTypes) {
        super(listingPrice);
        this.bathroomNumbers = bathroomNumbers;
        this.depthOfTheLot = depthOfTheLot;
        this.withOfTheLot = withOfTheLot;
        this.floorSpace = floorSpace;
        this.bedroomNumbers = bedroomNumbers;
        this.houseTypes = houseTypes;
    }

    @Override
    public String toString() {
        return "House{" + "Listing Price=" + getListingPrice() +
                "\n"+
                "bathroomNumbers=" + bathroomNumbers +
                "\n"+
                ", depthOfTheLot=" + depthOfTheLot +
                "\n"+
                ", withOfTheLot=" + withOfTheLot +
                "\n"+
                ", floorSpace=" + floorSpace +
                "\n"+
                '}';
    }

    public String CompareMethod(Property property) {
        if (this.getListingPrice() > property.getListingPrice()) {
            return getClass() + " is more expensive." +"\n"+
                    "Difference between the two is " + abs(this.getListingPrice() - property.getListingPrice());


        } else {
            return getClass() + " is more expensive." +"\n"+
                    "Difference between the two is " + abs(this.getListingPrice() - property.getListingPrice());
        }


    }
}

class Land extends Property {
    private double Hectares;

    public Land(double listingPrice, double hectares) {
        super(listingPrice);
        Hectares = hectares;
    }

    public double getHectares() {
        return Hectares;
    }

    public void setHectares(double hectares) throws IllegalInput {
        if (hectares <= 0) {
            throw new IllegalInput("Hectares can't be less or equal to 0!");
        }

        Hectares = hectares;
    }

    @Override
    public String toString() {
        return "Land{" + "\n"+"Listing Price=" + getListingPrice() +
                "\n"+
                "Hectares=" + Hectares +"\n"+
                '}';
    }

    public void TaxCalculator() {
        double Tax_Land = 100 * getHectares();
        System.out.println(Tax_Land);
    }

    public String CompareMethod(Property property) {
        if (this.getListingPrice() > property.getListingPrice()) {
            return getClass() + " is more expensive." + "\n"+
                    "Difference between the two is " + abs(this.getListingPrice() - property.getListingPrice());


        } else {
            return getClass() + " is more expensive." +"\n"+
                    "Difference between the two is " + abs(this.getListingPrice() - property.getListingPrice());
        }

    }
}


    class Cottage extends House {


        private double lakeFrontage;

        public double getLakeFrontage() {
            return lakeFrontage;
        }

        public void setLakeFrontage(double lakeFrontage) throws IllegalInput {
            if (lakeFrontage <= 0){
                throw new IllegalInput("Lake Frontage can't be 0!");
            }

            this.lakeFrontage = lakeFrontage;
        }

        public Cottage(double listingPrice, int bathroomNumbers, double depthOfTheLot, double withOfTheLot, double floorSpace, int bedroomNumbers, HouseTypes houseTypes, double lakeFrontage) {
            super(listingPrice, bathroomNumbers, depthOfTheLot, withOfTheLot, floorSpace, bedroomNumbers,HouseTypes.WATERFRONT_HOME);
            this.lakeFrontage = lakeFrontage;
        }

        @Override
        public String toString() {
            return "Cottage{" +
                    "Listing Price =" + getListingPrice() +
                    "\n"+
                    "# of Bathrooms = " + getBathroomNumbers() +
                    "\n"+
                    "Depth of The Lot=" + getDepthOfTheLot() +
                    "\n"+
                    "Width of The Lot=" + getWithOfTheLot() +
                    "\n"+
                    "# of Floor Space=" + getFloorSpace() +
                    "\n"+
                    "lakeFrontage=" + lakeFrontage +"\n"+
                    '}';
        }

        public void TaxCalculator() {
            double Tax_Cottage = 2000 + 2 * getLakeFrontage();
            System.out.println(Tax_Cottage);
        }

        public String CompareMethod(Property property) {
            if (this.getListingPrice() > property.getListingPrice()) {
                return getClass() + " is more expensive." +"\n"+
                        "Difference between the two is " + abs(this.getListingPrice() - property.getListingPrice());


            } else {
                return getClass() + " is more expensive." +"\n"+
                        "Difference between the two is " + abs(this.getListingPrice() - property.getListingPrice());
            }

        }
    }


    class Farm extends Land {
        private String crops;

        public Farm(double listingPrice, double hectares, String crops) {
            super(listingPrice, hectares);
            this.crops = crops;
        }

        public String getCrops() {
            return crops;
        }

        public void setCrops(String crops) throws IllegalInput {
            if (crops.isEmpty()) {
                throw new IllegalInput("Crop type can't be empty!");
            }
            this.crops = crops;
        }

        @Override
        public String toString() {
            return "Farm{" + "\n"+"Listing Price=" + getListingPrice() + "\n"+"Hectares" + getHectares() +"\n"+
                    "crops='" + crops + '\'' +"\n"+
                    '}';
        }

        public void TaxCalculator() {
            double Tax_Farm = 50 * getHectares();
            System.out.println(Tax_Farm);
        }

        public String CompareMethod(Property property) {
            if (this.getListingPrice() > property.getListingPrice()) {
                return getClass() + " is more expensive." +"\n"+
                        "Difference between the two is " + abs(this.getListingPrice() - property.getListingPrice());


            } else {
                return getClass() + " is more expensive." +"\n"+
                        "Difference between the two is " + abs(this.getListingPrice() - property.getListingPrice());
            }


        }
    }

        class Office extends MultiUnitBuilding {

            @Override
            public int getNumberOfUnits() {
                return super.getNumberOfUnits();
            }

            @Override
            public void setNumberOfUnits(int numberOfUnits) throws IllegalInput {
                if (numberOfUnits <= 0) {

                    throw new IllegalInput("Units cant be 0!");
                }
                super.setNumberOfUnits(numberOfUnits);
            }

            @Override
            public double getFloorSpace() {
                return super.getFloorSpace();
            }

            @Override
            public void setFloorSpace(double floorSpace) throws IllegalInput {
                if (floorSpace <= 0){
                    throw new IllegalInput("Can't be 0!");
                }
                super.setFloorSpace(floorSpace);
            }

            enum OfficeTypes {
                SERVICE, SALES, INDUSTRIAL
            }

            private OfficeTypes officeTypes;


            public Office(double listingPrice, int numberOfUnits, double floorSpace, boolean hasElevator, OfficeTypes officeTypes) {
                super(listingPrice, numberOfUnits, floorSpace, hasElevator);
                this.officeTypes = officeTypes;
            }

            @Override
            public String toString() {
                return "Office{" +"\n"+ "Listing Price=" + getListingPrice() +
                        "\n"+"# of Units=" + getNumberOfUnits() +
                        "\n"+"Floor Space=" + getFloorSpace() +
                        "\n"+"Elevator?" + isHasElevator() +
                        "\n"+"officeTypes=" + officeTypes +"\n"+
                        '}';
            }


            public void TaxCalculator() {
                double officeTax;
                if (this.officeTypes == OfficeTypes.INDUSTRIAL) {
                    if (isHasElevator()) {
                        officeTax = 0.95 * (10 * getFloorSpace() + 20 * getNumberOfUnits() + 50);
                    } else {
                        officeTax = 0.95 * (10 * getFloorSpace() + 20 * getNumberOfUnits());
                    }

                } else if (this.officeTypes == OfficeTypes.SERVICE) {
                    if (isHasElevator()) {
                        officeTax = 0.85 * (10 * getFloorSpace() + 20 * getNumberOfUnits() + 50);
                    } else {
                        officeTax = 0.85 * (10 * getFloorSpace() + 20 * getNumberOfUnits());
                    }
                } else {
                    if (isHasElevator()) {
                        officeTax = 10 * getFloorSpace() + 20 * getNumberOfUnits() + 50;
                    } else {
                        officeTax = 10 * getFloorSpace() + 20 * getNumberOfUnits();
                    }
                }
                System.out.println(officeTax);
            }

            public String CompareMethod(Property property) {
                if (this.getListingPrice() > property.getListingPrice()) {
                    return getClass() + " is more expensive." +"\n"+
                            "Difference between the two is " + abs(this.getListingPrice() - property.getListingPrice());


                } else {
                    return getClass() + " is more expensive." +"\n"+
                            "Difference between the two is " + abs(this.getListingPrice() - property.getListingPrice());
                }


            }
        }


        class ApartmentBuilding extends MultiUnitBuilding {
            private int numOfTenants;

            public int getNumOfTenants() {
                return numOfTenants;
            }

            public void setNumOfTenants(int numOfTenants) {
                this.numOfTenants = numOfTenants;
            }

            public ApartmentBuilding(double listingPrice, int numberOfUnits, double floorSpace, boolean hasElevator, int numOfTenants) {
                super(listingPrice, numberOfUnits, floorSpace, hasElevator);
                this.numOfTenants = numOfTenants;
            }


            @Override
            public String toString() {
                return "ApartmentBuilding{" +"\n"+
                        "Listing Price= " + getListingPrice() +
                        "\n"+ "# of Units =" + getNumberOfUnits() +
                        "\n"+ "# of Floor Space=" + getFloorSpace() +
                        "\n"+ "Elevator ?" + isHasElevator() +
                        "\n"+ "numOfTenants=" + numOfTenants +"\n"+
                        '}';
            }

            public void TaxCalculator() {
                double Tax_Apartment = 35 * getFloorSpace();
                System.out.println(Tax_Apartment);
            }

            public String CompareMethod(Property property) {
                if (this.getListingPrice() > property.getListingPrice()) {
                    return getClass() + " is more expensive." +"\n"+
                            "Difference between the two is " + abs(this.getListingPrice() - property.getListingPrice());


                } else {
                    return getClass() + " is more expensive." +"\n"+
                            "Difference between the two is " + abs(this.getListingPrice() - property.getListingPrice());
                }

            }

            public void setNumberOfUnits(int numberOfUnits) throws IllegalInput {
                if (numberOfUnits <= 0) {

                    throw new IllegalInput("Units cant be 0!");
                }
                super.setNumberOfUnits(numberOfUnits);
            }

            @Override
            public double getFloorSpace() {
                return super.getFloorSpace();
            }

            @Override
            public void setFloorSpace(double floorSpace) throws IllegalInput {
                if (floorSpace <= 0){
                    throw new IllegalInput("Can't be 0!");
                }
                super.setFloorSpace(floorSpace);
            }


        }

        class IllegalInput extends Exception {

            public IllegalInput(String message) {
                System.out.println(message);
            }

        }






