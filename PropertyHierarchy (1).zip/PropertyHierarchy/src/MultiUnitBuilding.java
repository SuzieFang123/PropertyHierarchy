public class MultiUnitBuilding extends Property {
    private int numberOfUnits;
    private double floorSpace;
    private boolean hasElevator;


    @Override
    public void TaxCalculator() {

    }

    @Override
    public String CompareMethod(Property property) {
        return null;
    }

    public int getNumberOfUnits() {
        return numberOfUnits;
    }

    public void setNumberOfUnits(int numberOfUnits) throws IllegalInput {
        if (numberOfUnits <=0){
            throw new IllegalInput("Units cant be 0!");
        }
        this.numberOfUnits = numberOfUnits;
    }

    public double getFloorSpace() {
        return floorSpace;
    }

    public void setFloorSpace(double floorSpace) throws IllegalInput {
        if (floorSpace <= 0){
            throw new IllegalInput("Floor Space can't be 0");
        }
        this.floorSpace = floorSpace;
    }

    public boolean isHasElevator() {
        return hasElevator;
    }

    public void setHasElevator(boolean hasElevator) {
        this.hasElevator = hasElevator;
    }

    public MultiUnitBuilding(double listingPrice, int numberOfUnits, double floorSpace, boolean hasElevator) {
        super(listingPrice);
        this.numberOfUnits = numberOfUnits;
        this.floorSpace = floorSpace;
        this.hasElevator = hasElevator;
    }
}