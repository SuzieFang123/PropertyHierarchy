import java.util.ArrayList;

abstract public class Property {
    private double listingPrice;

    // Constructor for listing price
    public Property(double listingPrice) {
        this.listingPrice = listingPrice;
    }


    // Getter for listing price
    public double getListingPrice() {
        return listingPrice;
    }

    // Setter for listing price

    public void setListingPrice(double listingPrice) throws IllegalInput {
        if(listingPrice <= 0){
            throw new IllegalInput("Listing price can't be less then 0!");
        }
        this.listingPrice = listingPrice;
    }

    public abstract void TaxCalculator();
    public abstract String CompareMethod(Property property);


    public static void main(String[] args) {
        ArrayList<Property> propertyDB = new ArrayList<Property>();
        Property farm = new Farm(232,2.1,"Cherry");
        Property house =new House(12312,3,34324,434,5,3, House.HouseTypes.TOWNHOUSE);
        Property land = new Land(6332,90);
        Property cottage = new Cottage(12314,2,54,1234,6456,6, House.HouseTypes.WATERFRONT_HOME,65);
        Property office = new Office(4322,12,643,true, Office.OfficeTypes.INDUSTRIAL);
        Property multiunit = new MultiUnitBuilding(12312,43,232,true);

        propertyDB.add(farm);
        propertyDB.add(house);
        propertyDB.add(land);
        propertyDB.add(cottage);
        propertyDB.add(office);
        propertyDB.add(multiunit);

        for(Property property:propertyDB){
            System.out.println(property);
            System.out.println("Tax of " + property.getClass() + " is "); property.TaxCalculator();
        }
        System.out.println(office.CompareMethod(farm));
        System.out.println(cottage.CompareMethod(house));




    }


}
